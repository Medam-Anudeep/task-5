package com.epamtak5.loggingtask;
import java.io.IOException;
public class Calculatearea {
	 public static void main( String[] args ) throws IOException
	 {
			
	    	HouseConstruction a=new HouseConstruction();
	    	a.valuesofmaterials();
	 }

}
